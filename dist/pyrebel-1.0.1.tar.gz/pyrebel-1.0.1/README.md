# pyrebel
A pure python library that implements abstraction of data.

# Read more about the methods <a href="https://github.com/ps-nithin/pyrebel/blob/main/intro-r2.pdf">here</a>

# Let the data shine!

